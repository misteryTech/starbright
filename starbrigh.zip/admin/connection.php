<?php
    $localhost = "localhost";
    $username = "root";
    $password = "";
    $dbname = "starbright";

   $conn = mysqli_connect($localhost, $username, $password, $dbname);

?>